# The L2 NFT Markerplace Built For Earth

Buy and Sell NFTs on L2 at NFTEarth! NFTs are for everyone - NFTEarth is for all.
 
 <h1 align="center"> 
NFTEarth is an opensource L2 NFT marketplace built with Reservoir.
 <p align="center">
 
![NFTEArth](https://user-images.githubusercontent.com/29180454/217692985-4e705c2e-0656-4354-a241-0153c3f60bfd.png)
[![npm version](https://img.shields.io/npm/v/generator-awesome-list.svg?style=flat-square)](https://www.npmjs.com/package/generator-awesome-list)

<!-- ABOUT THE PROJECT -->

![image](https://user-images.githubusercontent.com/29180454/222880577-0043c5bc-0484-49ac-b174-5e5283ed603f.png)



<p align="center"><a href="#top">Project Information:</a></p>





<p align="center">

## Twitter: [NFTEarth](https://twitter.com/NFTEarth_L2)

## Discord: [NFTEarth](https://discord.gg/nftearth)

## App: [NFTEarth](https://nftearth.exchange) 

## Documentation: [Docs](https://docs.nftearth.exchange)

</p>
