export const LaunchPadTileInfo = [
  {
    title: 'Art generation',
    description: '',
    link: '',
  },
  {
    title: 'Smart contracts',
    description: '',
    link: '',
  },
  {
    title: 'Allowlist management',
    description: '',
    link: '',
  },
  {
    title: 'Embed button for use in apps',
    description: '',
    link: '',
  },
  {
    title: 'Presale/Public sale custimizations',
    description: '',
    link: '',
  },
  {
    title: 'Creator Privilege',
    description:
      'Ability for creator to have their own portal to set all things they want: e.g. Twitter, Discord, Royalties, GitHub, their own Affiliate links, etc.',
    link: '',
  },
]
