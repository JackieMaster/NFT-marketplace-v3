export const data = [
    {
        rank: 1,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 2,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 3,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 4,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 5,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 6,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 7,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 8,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 9,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 10,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 11,
        username: 'test',
        volume: 100000,
        reward: 100
    },
    {
        rank: 12,
        username: 'test',
        volume: 100000,
        reward: 100
    }
]